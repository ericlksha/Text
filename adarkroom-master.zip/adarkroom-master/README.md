A Dark Room
=========

A Minimalist Text Adventure Game

[Chinese translation](https://github.com/Tedko/CHN-Ver-of-ADarkRoom)

[Click to play](http://adarkroom.doublespeakgames.com/)


***Another Chinese Dark Room***
- [Home page](http://dreamz.cn/a-dark-room/index.html?lang=cn)  Some Translations come from U77 team.
- [Git Repo](http://github.com/lilj/adarkroom)


