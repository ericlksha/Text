var langs = {
 'en':'english',
 'fr':'français',
 'cn':'简体中文',
 'jp':'日本語'
}
